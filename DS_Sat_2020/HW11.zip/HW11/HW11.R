library(dplyr)
#slide 4 task 1
df<-read.csv("results.csv",stringsAsFactors = F)
df<-df[df$home_score!=df$away_score,]
df$winning<-ifelse(df$home_score>df$away_score,df$home_team,df$away_team)

number<-df%>% group_by(winning)%>%summarise(num=n())

library(highcharter)
hcmap("custom/world-eckert3-lowres", data = number, value = "num",
      joinBy = c("name", "winning"), name = "Number of wins",
      dataLabels = list(enabled = TRUE, format = '{point.name}'),
      borderColor = "#FAFAFA", borderWidth = 0.1,
      tooltip = list(valueDecimals = 0, valuePrefix = "", valueSuffix = " wins")) %>% 
  hc_mapNavigation(enabled = TRUE) 

#slide 4 task 2
df<-read.csv("seattleWeather_1948-2017.csv")
sum(is.na(df$PRCP))
df$PRCP<-na.approx(df$PRCP)
library(zoo)
timeseries<-ts(df$PRCP,frequency=365,start = c(1948, 1))
dc<-decompose(timeseries)
plot(dc) #there is seasonal
df$TMAX<-(df$TMAX-32)*5/9
df$TMIN<-(df$TMIN-32)*5/9
cor(df[,2:4]) #there is no correlation, so we use ts for prognoses
library(forecast)
library(plm)
progn<-auto.arima(timeseries-dc$seasonal) #ARIMA(4,0,0)
progn
forc<-forecast(progn,50)

forc$x<-forc$x+dc$seasonal
dc$figure %in% tail(dc$seasonal)
forc$lower<-forc$lower+dc$seasonal[2:51]
forc$upper<-forc$upper+dc$seasonal[2:51]
plot(forc,xlim=c(2016,2019))
