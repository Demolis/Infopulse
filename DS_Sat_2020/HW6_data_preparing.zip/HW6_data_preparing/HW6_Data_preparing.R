#NN dataframes preparing

en_use <- read.csv("API_EG.USE.PCAP.KG.OE_DS2_en_csv_v2_10516087.csv", skip = 4)
imp_goods <- read.csv("API_NE.IMP.GNFS.ZS_DS2_en_csv_v2_10515590.csv", skip = 4)
tot_res <- read.csv("API_FI.RES.TOTL.CD_DS2_en_csv_v2_10515336.csv", skip = 4)
lit_rate <- read.csv("API_SE.ADT.LITR.ZS_DS2_en_csv_v2_10515259.csv", skip = 4)
life_exp <- read.csv("API_SP.DYN.LE00.IN_DS2_en_csv_v2_10515254.csv", skip = 4)

df<-rbind(en_use,imp_goods,tot_res,lit_rate,life_exp)

#the part of NA in parameters
sum(is.na(en_use))/(nrow(en_use)*(ncol(en_use)-4))
sum(is.na(imp_goods))/(nrow(imp_goods)*(ncol(imp_goods)-4))
sum(is.na(tot_res))/(nrow(tot_res)*(ncol(tot_res)-4))
sum(is.na(lit_rate))/(nrow(lit_rate)*(ncol(lit_rate)-4)) # 85,5 % of NA !!! so, we can delete it 
sum(is.na(life_exp))/(nrow(life_exp)*(ncol(life_exp)-4))

#the part of NA in years
df<-rbind(en_use,imp_goods,tot_res,life_exp)

year_na<-apply(is.na(df),2,sum)/nrow(df)

sum(year_na>0.4)

colnames(df[,year_na>0.4]) # we delete these years

df2<-df[,year_na<=0.4]


#the part of NA in countries

df2$na_num<-apply(is.na(df2),1,sum)

country_na<-df2%>%group_by(Country.Name)%>%summarise(na=(sum(na_num)/(4*(ncol(df2)-4))))

sum(country_na$na>0.3)
country_na[country_na$na>0.3,] # we delete these countries

df3<-df2[df2$Country.Name %in% country_na[country_na$na<=0.3,]$Country.Name,]

#use na.approx
df3$na_num<-NULL
library(zoo)
df4<-df3

sum(is.na(df4))

for (i in 1:nrow(df4)){
  df4[i,5:ncol(df4)]<-na.approx(t(df4[i,5:ncol(df4)]),na.rm = F)
}
sum(is.na(df4))


#transform of df
df5<-gather(df4,Year,Value,X1974:X2016)
df5$Indicator.Code<-NULL
df5$Country.Code<-NULL
df6<-spread(df5,Indicator.Name, Value)
library(mice)
colnames(df6)<-c("Country","Year","EnUse","Import","TotRes","LifeExp")
imp<-mice(df6[,3:6],1,method="rf")
df6<-complete(imp,1)
md.pattern(df6)
