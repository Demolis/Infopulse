
library(dplyr)
library(neuralnet)
library(mice)
library(rpart)
library(rpart.plot)

#Task 1

df <- read.csv(file = "train.csv")
str(df)
df$Id<-NULL

#replace NA in factor columns
for (i in 1:ncol(df)){
  if(is.factor(df[,i])){
    df[,i]<-as.integer(df[,i])
    df[is.na(df[,i]),i]<-0
  }
}
#replace NA

mice_model<-mice(df,1,method = "rf")
df<-complete(mice_model,1)
md.pattern(df)


samplesize = 0.60 * nrow(df)

index = sample( seq_len(nrow(df)), size = samplesize )

## NN
## Scale data for neural network
max = apply(df , 2 , max)
min = apply(df, 2 , min)
scaled = as.data.frame(scale(df, center = min, scale = max - min))
scaled

## Fit neural network 

# creating training and test set
trainNN = scaled[index , ]
testNN = scaled[-index , ]

# fit neural network
f<-paste(colnames(trainNN[,-ncol(trainNN)]), collapse=" + ")
f<-as.formula(paste("SalePrice ~", f, collapse=""))
NN<-neuralnet(f, trainNN, hidden = c(8,5,3),rep=100)
min(NN$result.matrix[1,])
which.min(NN$result.matrix[1,])
# plot neural network
plot(NN,rep=100)
NN
## Prediction using neural network

predict_testNN <- compute(NN, testNN[,-ncol(trainNN)],rep=100)

predict_testNN = (predict_testNN$net.result * (max(df$SalePrice) - min(df$SalePrice))) + min(df$SalePrice)

plot(df[-index,]$SalePrice, predict_testNN, col='blue', pch=16, ylab = "predicted NN", xlab = "real")

abline(0,1)
# Calculate Root Mean Square Error (RMSE)
RMSE.NN = (sum((df[-index,]$SalePrice - predict_testNN)^2) / nrow(testNN)) ^ 0.5
RMSE.NN/median(df$SalePrice)*100


## Decision Tree
# creating training and test set
train = df[index , ]
test = df[-index , ]


model_cer<-rpart(f,
                 data = train, method = "anova",
                 control=rpart.control(cp=0.001))
model_cer

fancyRpartPlot(model_cer)

pred<-predict(model_cer, newdata = test, type="vector")

sqrt(sum((pred - test$SalePrice)^2)/length(pred))/median(df$SalePrice)*100

#the set of trees

ntrees <- 300
res <- numeric(ntrees)
prd <- numeric(nrow(test))
for(i in 1:ntrees){
  x <- runif(nrow(train))>0.2;
  y <- runif(ncol(train))>0.2;
  y[length(y)] <- TRUE
  traindata <- train[x,y]
  tree <- rpart(SalePrice ~ ., traindata, control=rpart.control(cp=.0))
  prd <- prd + predict(tree, test)
  predictions <- prd / i
  res[i] <- sqrt(sum((predictions - test$SalePrice)^2)/length(predictions))/median(df$SalePrice)
  print(res[i])
}
plot(res,type="l")
res[300]


#Task 2

df <- read.csv(file = "Day6-titanic.csv")
str(df)
df$PassengerId<-NULL
df$Name<-NULL
df$Ticket<-NULL
df$Cabin<-NULL
#replace NA
mice_model<-mice(df,1,method = "rf")
df<-complete(mice_model,1)
md.pattern(df)


samplesize = 0.60 * nrow(df)

index = sample( seq_len(nrow(df)), size = samplesize )

## Decision Tree
# creating training and test set
train = df[index , ]
test = df[-index , ]


model_cer<-rpart(Survived~.,
                 data = train, method = "anova",
                 control=rpart.control(cp=0.01)) #try 0.001
model_cer

fancyRpartPlot(model_cer)

pred<-predict(model_cer, newdata = test, type="vector")

sqrt(sum((pred - test$Survived)^2)/length(pred))

df$Survived<-as.factor(df$Survived)
train = df[index , ]
test = df[-index , ]
rf <- randomForest(Survived~., train)
predictions <- predict(rf, test)
sqrt(sum((as.integer(predictions) - as.integer(test$Survived))^2)/length(predictions))
importance(rf)
