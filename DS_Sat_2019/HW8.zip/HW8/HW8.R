library(dplyr)
library(readr)
df<- read_csv("simpsons_episodes.csv") #because of specific file
str(df)

#3. Какой сезон был наиболее успешным? 
rating<-df%>%group_by(season)%>%summarise(us_mil=mean(us_viewers_in_millions,na.rm=T),views=mean(views,na.rm=T),imdb_r=mean(imdb_rating*imdb_votes,na.rm=T))
max <- apply(rating[,2:4], 2 , max)
min <- apply(rating[,2:4], 2 , min)
scaled <- as.data.frame(scale(rating[,2:4], center = min, scale = max - min))
rating[,5]<-rowSums(scaled) #we construct complex indicator
rating<-as.data.frame(rating)
plot(rating[,1],rating[,5])

#4. Верна ли гипотеза о том, что популярность сериала падает? Стоит ли продолжать снимать сериал?
# look at 3

#5. Сделайте прогноз количества зрителей в США следующих 10 серий.
library(zoo)
df$us_viewers_in_millions<-na.approx(df$us_viewers_in_millions)
TS<-ts(df%>%arrange(number_in_series)%>%select(us_viewers_in_millions))
plot(TS)
decompose(TS)
library(forecast)
library(plm)
pred_model<-auto.arima(TS)
pred<-forecast(pred_model,10)
plot(pred,xlim=c(580,615))
#6. Распределены ли оценки на IMDB по нормальному закону? А количество этих оценок? 
shapiro.test(df$imdb_rating) #no
shapiro.test(df$imdb_votes) #no
#7. Какая зависимость между параметрами: оценка на IMDB, количество оценок и количество зрителей в США.
cor(cbind(df$imdb_rating,df$us_viewers_in_millions,df$imdb_votes),use="pairwise.complete.obs")
plot(df$imdb_rating,df$us_viewers_in_millions) #there is a small dependence
plot(df$us_viewers_in_millions,df$imdb_votes)
plot(df$imdb_rating,df$imdb_votes)

