library(shiny)
library(tm)
library(wordcloud)

shinyServer(function(input, output) {
  output$wordPlot <- renderPlot({
  if (is.null(input$file1))
    return(NULL)
    conect<-file(input$file1$datapath,"r", blocking = FALSE)
  textL<- VCorpus(VectorSource(readLines(con<-conect))) 
close(conect)
  textL <- tm_map(textL,removePunctuation)   
  textL <- tm_map(textL, removeNumbers) 
  textL <- tm_map(textL, tolower)   
  textL <- tm_map(textL, removeWords, stopwords('english'))   
  textL <- tm_map(textL, PlainTextDocument)
  textL <- tm_map(textL, stripWhitespace)  
  
  textL <- tm_map(textL, PlainTextDocument)
  
  
  dtm <- DocumentTermMatrix(textL) #   TermDocumentMatrix
  freq <- colSums(as.matrix(dtm))   
  
  
  wordcloud(names(freq), freq,max.words = input$kol) 
  })
})
