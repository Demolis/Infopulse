

dn<-read.csv("DN.csv",sep=";",dec=",")
vrp<-read.csv("VRP.csv",sep=";",dec=",")

#apply, sapply or lapply

#first task
num<-apply(dn[,-1], 2, function(x) sum(na.omit(x)>mean(x,na.rm = T)))

#second task
apply(vrp, 1, function(x) plot(2006:2015,x[-1],type = "l",main=x[1],xlab="Year",ylab="VRP"))
