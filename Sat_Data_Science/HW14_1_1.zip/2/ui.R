library(shiny)

shinyUI(pageWithSidebar(
  headerPanel("TXT Viewer"),
  sidebarPanel(
    fileInput('file1', 'Choose TXT File',
              accept=c('.txt')),
    sliderInput("kol", "Integer:", 
                min=0, max=150, value=5)
  ),
  mainPanel(
    plotOutput('wordPlot')
  )
))
